// global variables for game
var choices = ['rock', 'paper', 'scissors'];
var computers_choice;
var players_choice;
var player_lives = 3;
var computer_lives = 3;
var message_area = document.getElementById('game_area');
var cleararea = false;
var name = prompt("Who is gonna play?");
var picture = ['therock', 'thepaper', 'thescissors']

document
    .getElementById('playGame')
    .addEventListener('click', runGame)
    .getElementById("imagen1")
    .getElementById("imagen2")

// game logic
function runGame() {
  if (cleararea) {
    message_area.innerHTML = '';
  }

  clearArea = false;
  // initial messaging
  message_area.innerHTML += '*************<br />';
  message_area.innerHTML +='Computer lives: ' + computer_lives + '<br />';
  message_area.innerHTML +='Player lives: ' + player_lives + '<br />';
  message_area.innerHTML +='Choose your weapon!' + '<br />';
  message_area.innerHTML +='*************<br />';

  // setting game choices
  var players_choice = document.getElementById('gameOption')
  players_choice = players_choice.options[players_choice.selectedIndex].value;
  computers_choice = choices[Math.floor(Math.random() * choices.length)];

  console.log('*************');
  console.log('Computer chose: ' + computers_choice);
  console.log('Player chose: ' + players_choice);
  console.log('*************');

  // conditionals for actual game logic
  if (players_choice == computers_choice) {
    console.log('Tie! No one wins, play again.');
  } else if (players_choice == 'rock') {
    checkComputerWins('paper', 'covers', 'smashes');
  } else if (players_choice == 'paper') {
    checkComputerWins('scissors', 'cuts', 'covers');
  } else if (players_choice == 'scissors') {
    checkComputerWins('rock', 'smashes', 'cuts');
  } else {
    console.log("Well that's not a valid choice");
  }

  // restart game loop
  checkStatus();
}

// checks whether computer wins against player choice
function checkComputerWins(validateChoice, winMessage, loseMessage) {
  if (computers_choice == validateChoice) {
    console.log('You lose! ' + computers_choice + ' ' + winMessage + ' ' + players_choice + '<br />');
    player_lives = player_lives - 1;
  } else {
    console.log('You win! ' + players_choice + ' ' + loseMessage + ' ' + computers_choice + '<br />');
    computer_lives = computer_lives - 1;
  }
}

//  check status of game
function checkStatus() {
  if (player_lives == 0) {
    showWinLoseMessage("lost");
  } else if (computer_lives == 0) {
    showWinLoseMessage("won");
  } else {
    message_area.innerHTML += 'Select another choice!<br />';
    message_area.innerHTML += '*********** <br /><br />';
  }
}

// messaging for winning or losing
function showWinLoseMessage(status) {
  message_area.innerHTML += '*************<br />';
  message_area.innerHTML += 'Game over.<br />';
  message_area.innerHTML += '*************<br />';
  message_area.innerHTML += 'You ' + status + '! Would you like to play again?<br />';
  alert(" "+name+", You have "+status+"");
}

function btn1(){

	var imagen = document.getElementById("imagen1");

	if(picture == "therock"){
		imagen.src = "img/piedra.png";
		picture = "papel";
	}
	else{
		imagen.src = "img/piedra.png";
		picture = "therock";
	}
}

function btn2(){

	var imagen = document.getElementById("imagen1");

	if(picture == "thepaper"){
		imagen.src = "img/papel.png";
		picture = "nopapel";
	}
	else{
		imagen.src = "img/papel.png";
		picture = "thepaper";
	}
}		

function btn3(){

	var imagen = document.getElementById("imagen1");

	if(picture == "thescissors"){
		imagen.src = "img/tijera.png";
		picture = "notijera";
	}
	else{
		imagen.src = "img/tijera.png";
		picture = "thescissors";
	}	

}

function imageChanger(){

	var imagen = document.getElementById("imagen1");
	var players_choice = document.getElementById('gameOption')
    players_choice = players_choice.options[players_choice.selectedIndex].value;

	if(players_choice =="rock"){
		imagen.src = "img/piedra.png";
		players_choice = "therocck";
	}
	else if(players_choice =="paper"){
		imagen.src = "img/papel.png";
		players_choice = "thepape";
}
	else if(players_choice =="scissors"){
		imagen.src = "img/tijera.png";
		players_choice = "thescciso";
	}
	else{
		imagen.src = "img/chose.png";
		players_choice = "thechoser";
	}

}




